import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Optional;

public abstract class TipoColaborador {

	private String cpf;
	private String nome;
	private String email;
	private ArrayList<RegistroPonto> registros;

	public TipoColaborador(String cpf, String nome, String email) {
		this.cpf = (cpf != null) ? cpf.trim() : "";
		this.nome = (nome != null) ? nome : "";
		this.email = (email != null) ? email : "";
		this.registros = new ArrayList<>();

		if (this.cpf.length() == 11 && this.cpf.matches("\\d{11}")) {
			System.out.println("-----------------------------------");
			System.out.println("Colaborador cadastrado com sucesso!");
			System.out.println("-----------------------------------");
		} else {
			System.out.println("ERRO: CPF inválido!");
			this.cpf = "";
		}
	}

	public String getCpf() {
		return cpf;
	}

	public String getNome() {
		return nome;
	}

	public String getEmail() {
		return email;
	}

	public abstract int getJornadaDiariaHoras();

	public void registraEntrada(LocalDateTime dataHora) {
		if (dataHora == null) {
			System.out.println("ERRO: Informe a data e hora da entrada!");
			return;
		}
		registros.add(new RegistroPonto(dataHora)); 
		System.out.println("------- Entrada -------");
		System.out.println("Entrada registrada para " + nome + " às "
				+ dataHora.format(DateTimeFormatter.ofPattern("dd/MM HH:mm'h'")));
	}

	public void registraSaida(LocalDateTime saida) {
		if (saida == null) {
			System.out.println("ERRO: Informe a data e hora da saída!");
			return;
		}

		Optional<RegistroPonto> aberto = registros.stream().filter(registro -> !registro.pontoFechado()).findFirst();

		if (aberto.isEmpty()) {
			System.out.println("ERRO: Não existe nenhum registro de entrada!");
			return;
		}

		LocalDateTime entrada = aberto.get().getEntrada();
		if (entrada == null) {
			System.out.println("ERRO: Registro aberto inválido!");
			return;
		}

		if (saida.isBefore(entrada)) {
			System.out.println("ERRO: Não é possível realizar um registro de saída antes da entrada!");
			return;
		}

		aberto.get().registraSaida(saida);
		System.out.println("------- Saída -------");
		System.out.println("Saída registrada para " + nome + " às " + saida.format(DateTimeFormatter.ofPattern("dd/MM HH:mm'h'")));
	}

	public ArrayList<RegistroPonto> getRegistros() {
		return new ArrayList<>(registros);
	}

	@Override
	public String toString() {
		return nome + " - CPF: " + cpf + " - " + getClass().getSimpleName();
	}
}