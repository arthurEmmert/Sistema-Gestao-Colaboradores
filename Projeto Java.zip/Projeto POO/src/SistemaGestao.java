import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class SistemaGestao {
	public static void main(String[] args) {
		RepositorioColaborador repo = new RepositorioColaborador();
		Scanner tec = new Scanner(System.in);

		// Colaboradores de teste
		repo.adicionar(new ColaboradorCLT("12345678901", "João Silva", "joao@email.com"));
		repo.adicionar(new ColaboradorEstagiario("55555555555", "Maria Oliveira", "maria@estagio.com"));
		repo.adicionar(new ColaboradorCLT("11111111111", "Pedro Santos", "pedro@empresa.com"));

		// ──────────────── Registros de ponto de teste ─────────────────────
		TipoColaborador joao = repo.buscarPorCpf("12345678901");
		if (joao != null) {
			joao.registraEntrada(LocalDateTime.of(2026, 10, 1, 8, 0)); // 01/10/2025 08:00
			joao.registraSaida(LocalDateTime.of(2026, 10, 1, 17, 30)); // 01/10/2025 17:30
		}

		TipoColaborador maria = repo.buscarPorCpf("55555555555");
		if (maria != null) {
			maria.registraEntrada(LocalDateTime.of(2026, 10, 2, 9, 0));
			maria.registraSaida(LocalDateTime.of(2026, 10, 2, 15, 0)); // Estagiário ~6h
		}

		TipoColaborador pedro = repo.buscarPorCpf("11111111111");
		if (pedro != null) {
			pedro.registraEntrada(LocalDateTime.of(2026, 10, 3, 8, 15));
			pedro.registraSaida(LocalDateTime.of(2026, 10, 3, 20, 0)); // +1h extra
		}

		while (true) {
			System.out.println("======= Sistema Gestão =======");
			System.out.println("Selecione uma opção:");
			System.out.println("1. Cadastrar colaborador");
			System.out.println("2. Registrar entrada");
			System.out.println("3. Registrar Saída");
			System.out.println("4. Consultar horas em um dia");
			System.out.println("5. Listar colaboradores com horas excedentes");
			System.out.println("6. Listar colaboradores cadastrados");
			System.out.println("7. Excluir colaborador");
			System.out.println("0. Sair.");
			System.out.print("Opção: ");
			int opcao = tec.nextInt();
			tec.nextLine();

			switch (opcao) {
				case 0:
					System.out.println("Fechando o sistema...");
					return;

				case 1:
					cadastrar(tec, repo);
					System.out.println("\nPressione 'Enter' para voltar!");
					tec.nextLine();
					break;

				case 2:
					entrada(tec, repo);
					System.out.println("\nPressione 'Enter' para voltar!");
					tec.nextLine();
					break;

				case 3:
					saida(tec, repo);
					System.out.println("\nPressione 'Enter' para voltar!");
					tec.nextLine();
					break;

				case 4:
					horasDia(tec, repo);
					System.out.println("\nPressione 'Enter' para voltar!");
					tec.nextLine();
					break;

				case 5:
					excedentes(tec, repo);
					System.out.println("\nPressione 'Enter' para voltar!");
					tec.nextLine();
					break;

				case 6:
					listar(tec, repo);
					System.out.println("\nPressione 'Enter' para voltar!");
					tec.nextLine();
					break;

				case 7:
					remover(tec, repo);
					System.out.println("\nPressione 'Enter' para voltar!");
					tec.nextLine();
					break;

				default:
					System.out.println("Opção inválida");
					break;
			}
		}
	}

	private static void cadastrar(Scanner tec, RepositorioColaborador repo) {
		System.out.println("------- Registrar Colaborador -------");
		System.out.println("Informe:");

		System.out.println("CPF: ");
		String cpf = tec.nextLine().trim();

		System.out.println("Nome: ");
		String nome = tec.nextLine().trim();
		if (!nome.matches("[a-zA-ZÀ-ÿ ]+")) {
			System.out.println("ERRO: Nome inválido!");
			return;
		}

		System.out.println("Email: ");
		String email = tec.nextLine().trim();

		System.out.println("1=CLT 2=Estágio: ");
		String tipo = tec.nextLine().trim();

		if ("1".equals(tipo))
			repo.adicionar(new ColaboradorCLT(cpf, nome, email));
		else if ("2".equals(tipo))
			repo.adicionar(new ColaboradorEstagiario(cpf, nome, email));
		else
			System.out.println("Tipo inválido");
	}

	private static void entrada(Scanner tec, RepositorioColaborador repo) {
		System.out.print("CPF: ");
		String cpf = tec.nextLine().trim();
		TipoColaborador colaborador = repo.buscarPorCpf(cpf);
		if (colaborador == null)
			return;
		LocalDateTime dataEntrada = lerDataHora(tec, "Entrada: ");
		if (dataEntrada != null)
			colaborador.registraEntrada(dataEntrada);

	}

	private static void saida(Scanner tec, RepositorioColaborador repo) {
		System.out.print("CPF: ");
		String cpf = tec.nextLine().trim();
		TipoColaborador colaborador = repo.buscarPorCpf(cpf);
		if (colaborador == null)
			return;
		LocalDateTime dataSaida = lerDataHora(tec, "Saída: ");
		if (dataSaida != null)
			colaborador.registraSaida(dataSaida);

	}

	private static void horasDia(Scanner tec, RepositorioColaborador repo) {
		System.out.print("CPF: ");
		String cpf = tec.nextLine().trim();
		System.out.print("Data dd/MM/yyyy: ");
		String d = tec.nextLine().trim();
		LocalDate data;
		try {
			data = LocalDate.parse(d, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		} catch (Exception e) {
			System.out.println("Data inválida");
			return;
		}

		double totalHoras = repo.calcularHorasNoDia(cpf, data);
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");
		System.out.println("------- Consultar Horas -------");
		System.out.printf("  Horas: %.2fh%n", totalHoras);

		TipoColaborador colaborador = repo.buscarPorCpf(cpf);
		if (colaborador != null) {
			int i = 1;
			for (RegistroPonto r : colaborador.getRegistros()) {
				if (r.getEntrada() != null && r.getEntrada().toLocalDate().equals(data)) {
					String entradaString = r.getEntrada().format(fmt) + "h";
					String saidaString = r.getSaida() != null ? r.getSaida().format(fmt) + "h" : "Aberto";
					System.out.printf(" [%d] Entrada %s / Saída %s%n", i++, entradaString, saidaString);
				}
			}
		}

	}

	private static void excedentes(Scanner tec, RepositorioColaborador repo) {
		LocalDate ini = lerData(tec, "Início dd/MM/yyyy: ");
		LocalDate fim = lerData(tec, "Fim dd/MM/yyyy: ");
		if (ini == null || fim == null)
			return;
		ArrayList<String> lista = repo.listarExcedentes(ini, fim);

		if (lista.isEmpty()) {
			System.out.println("Nenhum colaborador com horas excedentes!");
		} else {
			System.out.println("------- Horas Excedentes -------");
			for (String s : lista)
				System.out.println(s);
		}

	}

	private static void listar(Scanner tec, RepositorioColaborador repo) {
		System.out.println("------- Colaboradores Cadastrados -------");
		for (TipoColaborador c : repo.listarTodos()) {
			System.out.println(c);
		}

	}

	private static LocalDate lerData(Scanner tec, String msg) {
		System.out.print(msg);
		String s = tec.nextLine().trim();
		try {
			return LocalDate.parse(s, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		} catch (Exception e) {
			System.out.println("Formato errado! (EX: xx/xx/xxxx xx:xx");
			return null;
		}

	}

	private static LocalDateTime lerDataHora(Scanner tec, String msg) {
		System.out.print(msg);
		String s = tec.nextLine().trim();
		try {
			return LocalDateTime.parse(s, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
		} catch (Exception e) {
			System.out.println("Formato errado! (EX: xx/xx/xxxx xx:xx");
			return null;
		}

	}

	private static void remover(Scanner tec, RepositorioColaborador repo) {
		System.out.println("------- Excluir Colaborador -------");
		System.out.println("Informe o CPF do colaborador: ");
		String cpf = tec.nextLine().trim();
		repo.excluir(cpf);

	}
}