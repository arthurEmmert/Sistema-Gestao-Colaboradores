public class ColaboradorEstagiario extends TipoColaborador {
	public ColaboradorEstagiario(String cpf, String nome, String email) {
		super(cpf, nome, email);
	}

	@Override
	public int getJornadaDiariaHoras() {
		return 6;
	}
}