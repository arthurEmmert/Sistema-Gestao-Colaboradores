public class ColaboradorCLT extends TipoColaborador {
	public ColaboradorCLT(String cpf, String nome, String email) {
		super(cpf, nome, email);
	}

	@Override
	public int getJornadaDiariaHoras() {
		return 8;
	}
}