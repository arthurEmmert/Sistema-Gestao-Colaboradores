import java.time.LocalDate;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class RepositorioColaborador {
	private ArrayList<TipoColaborador> lista = new ArrayList<>();

	public void adicionar(TipoColaborador colab) {
		if (colab == null)
			return;

		String cpf = colab.getCpf();
		if (cpf == null)
			return;
		cpf = cpf.trim();

		if (cpf.length() != 11)
			return;

		for (TipoColaborador c : lista) {

			String cpfExistente = c.getCpf();
			if (cpfExistente != null && cpfExistente.trim().equals(cpf)) {
				return;
			}
		}
		lista.add(colab);
	}

	public TipoColaborador buscarPorCpf(String cpf) {
		if (cpf == null)
			return null;

		String limpo = cpf.trim();

		for (TipoColaborador c : lista) {

			String cpfExistente = c.getCpf();
			if (cpfExistente != null && cpfExistente.equals(limpo)) {
				return c;
			}
		}
		return null;
	}

	public ArrayList<TipoColaborador> listarTodos() {
		return new ArrayList<>(lista);
	}

	public double calcularHorasNoDia(String cpf, LocalDate data) {
		TipoColaborador c = buscarPorCpf(cpf);
		if (c == null)
			return 0;
		double total = 0;
		for (RegistroPonto r : c.getRegistros()) {
			if (r.getEntrada() != null && r.getEntrada().toLocalDate().equals(data)) {
				total += r.calculaHoras();
			}
		}
		return total;
	}

	public ArrayList<String> listarExcedentes(LocalDate ini, LocalDate fim) {

		return lista.stream()
				.map(c -> {
					double trabalhadas = c.getRegistros().stream()
							.filter(r -> r.getEntrada() != null)
							.filter(r -> !r.getEntrada().toLocalDate().isBefore(ini)
									&& !r.getEntrada().toLocalDate().isAfter(fim))
							.mapToDouble(RegistroPonto::calculaHoras)
							.sum();

					long diasTrabalhados = c.getRegistros().stream()
							.filter(r -> r.getEntrada() != null)
							.filter(r -> !r.getEntrada().toLocalDate().isBefore(ini)
									&& !r.getEntrada().toLocalDate().isAfter(fim))
							.map(r -> r.getEntrada().toLocalDate())
							.distinct()
							.count();

					double esperado = diasTrabalhados * c.getJornadaDiariaHoras();
					double excedeu = trabalhadas - esperado;
					return excedeu > 0
							? String.format("%s excedeu em %.0fh da sua jornada de trabalho", c.getNome(), excedeu)
							: null;
				}).filter(s -> s != null).collect(Collectors.toCollection((ArrayList::new)));
	}

	public void excluir(String cpf) {
		TipoColaborador c = buscarPorCpf(cpf);
		if (c == null) {
			System.out.println("Colaborador não encontrado!");
			return;
		}

		boolean temRegistroAberto = c.getRegistros().stream().anyMatch(r -> !r.pontoFechado());

		if (temRegistroAberto) {
			System.out.println("Não é possível excluir o colaborador! Existem registros abertos!");
			return;
		} else {
		lista.removeIf(colab -> colab.getCpf().equals(cpf));
			System.out.println("---------------------------------");
			System.out.println("Colaborador excluído com sucesso!");
			System.out.println("----------------------------------");
	   }
	}	
}