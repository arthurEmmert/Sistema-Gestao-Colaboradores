import java.time.LocalDateTime;
import java.time.Duration;

public class RegistroPonto {
	private LocalDateTime entrada;
	private LocalDateTime saida;

	public RegistroPonto(LocalDateTime entrada) {

		if (entrada == null) {
			throw new IllegalArgumentException("A entrada não pode ser nula!");
		}

		this.entrada = entrada;
		this.saida = null;
	}

	public void registraSaida(LocalDateTime saida) {
		if (saida == null) {
			throw new IllegalArgumentException("A saída não pode ser nula!");
		}
		if (saida.isBefore(entrada)) {
			throw new IllegalArgumentException("A saída não pode ser anterior a entrada!");
		}

		this.saida = saida;

	}

	public LocalDateTime getEntrada() {
		return entrada;
	}

	public LocalDateTime getSaida() {
		return saida;
	}

	public boolean pontoFechado() {
		return saida != null;
	}

	public double calculaHoras() {
		if (saida == null)
			return 0;
		return Duration.between(entrada, saida).toMinutes() / 60.0;
	}
}